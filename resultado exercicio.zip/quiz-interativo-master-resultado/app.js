const correctAnswers = ['A', 'A', 'A', 'A']

const form = document.querySelector('.quiz-form')
const score = document.querySelector('#userScore')





form.addEventListener('submit', event => {

    event.preventDefault()
    let userScore = 0



    const userAnswers = [
        form.inputQuestion1.value,
        form.inputQuestion2.value,
        form.inputQuestion3.value,
        form.inputQuestion4.value,
    ]
    //console.log(userAnswers)

    userAnswers.forEach((userAnswer, index) => {

        if (userAnswer === correctAnswers[index]) {

            userScore += 25

        }

    })
    score.innerHTML = `ÚLTIMA PONTUAÇÃO: ${userScore} pontos`



})

